
let numLines = 50;
let pointsPerLine = 300;
let noiseScale = 0.6;

function setup() {
  createCanvas(windowWidth, windowHeight);
  noFill();
  strokeWeight(1.5);
  colorMode(RGB);
  textFont('Orbitron');
  textStyle(BOLD);
  textAlign(LEFT, CENTER);
}

function draw() {
  background(15);
  noFill();

  let radius = min(width, height) * 0.15;
  let flowStrength = min(width, height) * 0.3;
  let centerX = width * 0.25;
  let centerY = height / 2;
  let separation = 25;

  translate(centerX, centerY);

  let colors = [
    color('#eccd6a'),
    color('#076464'),
    color('#eccd6a'),
    color('#076464'),
    color('#ffffff')
  ];

  for (let j = 0; j < numLines; j++) {
    beginShape();
    stroke(colors[j % colors.length]);
    let tOffset = map(j, 0, numLines, -1, 1);
    for (let i = 0; i <= pointsPerLine; i++) {
      let angle = map(i, 0, pointsPerLine, -PI / 2, PI / 2);
      let offsetRadius = map(j, 0, numLines, -10, 10);
      let x = cos(angle) * (radius + offsetRadius);
      let y = sin(angle) * (radius + offsetRadius) * 1.5;
      let n = noise(
        x * noiseScale * 0.01 + frameCount * 0.01 + j * 0.05,
        y * noiseScale * 0.01 + frameCount * 0.01 + j * 0.05
      );
      let offsetX = map(n, 0, 1, -flowStrength, flowStrength);
      x += offsetX * sin(angle);
      curveVertex(x, y + tOffset * 5);
    }
    endShape();
  }

  resetMatrix();
  let textX = centerX + radius + separation;
  let textY = centerY;
  textSize(min(width, height) * 0.1);
  fill("220");
  noStroke();
  text("WASTED\nTALENT", textX, textY);
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  redraw();
}

function keyPressed() {
  if (key === 's' || key === 'S') {
    save('redes1024.png');
  }
}
